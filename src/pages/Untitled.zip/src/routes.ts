import { createBrowserRouter } from "react-router";
import { Home } from "./pages/Home";
import { SpaceSimulation } from "./pages/SpaceSimulation";
import { Builder } from "./pages/Builder";
import { Education } from "./pages/Education";
import { AITutor } from "./pages/AITutor";

export const router = createBrowserRouter([
  {
    path: "/",
    Component: Home,
  },
  {
    path: "/simulation",
    Component: SpaceSimulation,
  },
  {
    path: "/builder",
    Component: Builder,
  },
  {
    path: "/education",
    Component: Education,
  },
  {
    path: "/ai-tutor",
    Component: AITutor,
  },
]);
