import { TrendingUp, Users, Globe, Award } from "lucide-react";

const stats = [
  {
    icon: Users,
    value: "10K+",
    label: "Active Students",
  },
  {
    icon: Globe,
    value: "2",
    label: "Languages",
  },
  {
    icon: TrendingUp,
    value: "95%",
    label: "Engagement Rate",
  },
  {
    icon: Award,
    value: "50+",
    label: "3D Exhibits",
  },
];

export function Stats() {
  return (
    <section className="relative py-24 px-6">
      <div className="relative z-10 max-w-7xl mx-auto">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
          {stats.map((stat, index) => (
            <div
              key={index}
              className="text-center group"
            >
              <div className="inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-purple-500/20 border border-purple-400/30 mb-4 group-hover:scale-110 group-hover:bg-purple-500/30 transition-all duration-300">
                <stat.icon className="w-8 h-8 text-purple-300" />
              </div>
              <div className="text-4xl md:text-5xl font-bold text-purple-100 mb-2">
                {stat.value}
              </div>
              <div className="text-sm text-purple-300/70">
                {stat.label}
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
