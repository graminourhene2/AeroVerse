import { Rocket, Github, Twitter, Linkedin } from "lucide-react";

export function Footer() {
  return (
    <footer className="relative border-t border-purple-400/20 py-12 px-6">
      <div className="max-w-7xl mx-auto">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-12 mb-12">
          {/* Brand */}
          <div className="col-span-1 md:col-span-2">
            <div className="flex items-center gap-2 mb-4">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-purple-500 to-purple-700 flex items-center justify-center shadow-lg shadow-purple-500/50">
                <Rocket className="w-5 h-5 text-white" />
              </div>
              <span className="text-xl font-semibold text-purple-100">
                AeroVerse
              </span>
            </div>
            <p className="text-purple-300/70 max-w-md">
              Transforming aerospace education through immersive VR experiences, real-time simulations, and AI-powered learning.
            </p>
          </div>

          {/* Links */}
          <div>
            <h4 className="font-semibold text-purple-100 mb-4">Platform</h4>
            <ul className="space-y-2">
              <li>
                <a href="#" className="text-purple-300/70 hover:text-purple-200 transition-colors">
                  Features
                </a>
              </li>
              <li>
                <a href="#" className="text-purple-300/70 hover:text-purple-200 transition-colors">
                  VR Museum
                </a>
              </li>
              <li>
                <a href="#" className="text-purple-300/70 hover:text-purple-200 transition-colors">
                  Simulations
                </a>
              </li>
              <li>
                <a href="#" className="text-purple-300/70 hover:text-purple-200 transition-colors">
                  AI Tutor
                </a>
              </li>
            </ul>
          </div>

          <div>
            <h4 className="font-semibold text-purple-100 mb-4">Company</h4>
            <ul className="space-y-2">
              <li>
                <a href="#" className="text-purple-300/70 hover:text-purple-200 transition-colors">
                  About
                </a>
              </li>
              <li>
                <a href="#" className="text-purple-300/70 hover:text-purple-200 transition-colors">
                  Contact
                </a>
              </li>
              <li>
                <a href="#" className="text-purple-300/70 hover:text-purple-200 transition-colors">
                  Privacy
                </a>
              </li>
              <li>
                <a href="#" className="text-purple-300/70 hover:text-purple-200 transition-colors">
                  Terms
                </a>
              </li>
            </ul>
          </div>
        </div>

        {/* Bottom */}
        <div className="pt-8 border-t border-purple-400/20 flex flex-col md:flex-row justify-between items-center gap-4">
          <p className="text-purple-300/60 text-sm">
            © 2026 AeroVerse. All rights reserved.
          </p>
          
          <div className="flex items-center gap-4">
            <a 
              href="#" 
              className="w-10 h-10 rounded-lg border border-purple-400/20 bg-purple-500/10 flex items-center justify-center hover:bg-purple-500/20 transition-colors"
            >
              <Twitter className="w-4 h-4 text-purple-300" />
            </a>
            <a 
              href="#" 
              className="w-10 h-10 rounded-lg border border-purple-400/20 bg-purple-500/10 flex items-center justify-center hover:bg-purple-500/20 transition-colors"
            >
              <Github className="w-4 h-4 text-purple-300" />
            </a>
            <a 
              href="#" 
              className="w-10 h-10 rounded-lg border border-purple-400/20 bg-purple-500/10 flex items-center justify-center hover:bg-purple-500/20 transition-colors"
            >
              <Linkedin className="w-4 h-4 text-purple-300" />
            </a>
          </div>
        </div>
      </div>
    </footer>
  );
}
