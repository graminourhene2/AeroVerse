import { Button } from "./ui/button";
import { Rocket, Menu, Sparkles, Wrench, GraduationCap, Bot } from "lucide-react";
import { Link, useLocation } from "react-router";

export function Navigation() {
  const location = useLocation();
  
  const navItems = [
    { path: "/simulation", label: "Simulation", icon: Sparkles },
    { path: "/builder", label: "Builder", icon: Wrench },
    { path: "/education", label: "Education", icon: GraduationCap },
    { path: "/ai-tutor", label: "AI Tutor", icon: Bot },
  ];

  return (
    <nav className="fixed top-0 left-0 right-0 z-50 px-6 py-4">
      <div className="max-w-7xl mx-auto">
        <div className="flex items-center justify-between rounded-2xl border border-purple-400/20 bg-[#0a0518]/80 backdrop-blur-xl px-6 py-4 shadow-lg shadow-purple-500/5">
          {/* Logo */}
          <Link to="/" className="flex items-center gap-2 hover:opacity-80 transition-opacity">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-purple-500 to-purple-700 flex items-center justify-center shadow-lg shadow-purple-500/50">
              <Rocket className="w-5 h-5 text-white" />
            </div>
            <span className="text-xl font-semibold text-purple-100">
              AeroVerse
            </span>
          </Link>

          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center gap-2">
            {navItems.map((item) => {
              const Icon = item.icon;
              const isActive = location.pathname === item.path;
              return (
                <Link
                  key={item.path}
                  to={item.path}
                  className={`flex items-center gap-2 px-4 py-2 rounded-xl transition-all ${
                    isActive
                      ? "bg-purple-600 text-white"
                      : "text-purple-200/70 hover:text-purple-100 hover:bg-purple-500/10"
                  }`}
                >
                  <Icon className="w-4 h-4" />
                  {item.label}
                </Link>
              );
            })}
          </div>

          {/* CTA Button */}
          <div className="flex items-center gap-4">
            <Button 
              className="hidden md:inline-flex bg-purple-600 hover:bg-purple-700 text-white rounded-xl"
            >
              Launch VR
            </Button>
            <Button 
              variant="ghost" 
              size="icon"
              className="md:hidden text-purple-200"
            >
              <Menu className="w-5 h-5" />
            </Button>
          </div>
        </div>
      </div>
    </nav>
  );
}