import { Navigation } from "../components/Navigation";
import { useState, useRef, useEffect } from "react";
import { Send, Sparkles, Globe, Mic, BookOpen, Lightbulb } from "lucide-react";
import { Button } from "../components/ui/button";

interface Message {
  id: string;
  role: "user" | "assistant";
  content: string;
  timestamp: Date;
}

const quickQuestions = [
  "How do rockets escape Earth's gravity?",
  "Explain orbital mechanics",
  "What is the difference between LEO and GEO?",
  "How does a satellite stay in orbit?",
  "What powers the International Space Station?",
];

const suggestions = [
  { icon: "🚀", title: "Rocket Science", topic: "How do multi-stage rockets work?" },
  { icon: "🌍", title: "Earth's Orbit", topic: "Why do satellites orbit the Earth?" },
  { icon: "⚡", title: "Energy Systems", topic: "How do spacecraft generate power?" },
  { icon: "🛰️", title: "Communications", topic: "How do we communicate with spacecraft?" },
];

export function AITutor() {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: "1",
      role: "assistant",
      content: "Hello! I'm Stella, your AI aerospace tutor. I'm here to help you understand the fascinating world of space and aeronautics. What would you like to learn about today? 🌟",
      timestamp: new Date(),
    },
  ]);
  const [input, setInput] = useState("");
  const [language, setLanguage] = useState<"en" | "fr">("en");
  const [isTyping, setIsTyping] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSend = async () => {
    if (!input.trim()) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      role: "user",
      content: input,
      timestamp: new Date(),
    };

    setMessages((prev) => [...prev, userMessage]);
    setInput("");
    setIsTyping(true);

    // Simulate AI response
    setTimeout(() => {
      const responses = [
        "That's a great question! Let me explain: Rockets work on Newton's Third Law of Motion - for every action, there's an equal and opposite reaction. The rocket expels hot gases downward at high speed, which pushes the rocket upward with tremendous force. 🚀",
        "Excellent inquiry! Orbital mechanics is all about balance. A satellite stays in orbit because it's moving fast enough horizontally that as it falls toward Earth due to gravity, the Earth curves away beneath it at the same rate. It's essentially falling around the planet! 🌍",
        "Interesting topic! The key difference is altitude. LEO (Low Earth Orbit) is typically 160-2,000 km above Earth, where satellites complete an orbit in ~90 minutes. GEO (Geostationary Orbit) is at 35,786 km, where satellites match Earth's rotation and appear stationary above a point. 📡",
        "Great thinking! Spacecraft use several power sources: solar panels that convert sunlight to electricity (most common), nuclear RTGs for deep space missions, and batteries for backup. The ISS, for example, has massive solar arrays generating 120 kW of power! ⚡",
      ];
      
      const aiMessage: Message = {
        id: (Date.now() + 1).toString(),
        role: "assistant",
        content: responses[Math.floor(Math.random() * responses.length)],
        timestamp: new Date(),
      };

      setMessages((prev) => [...prev, aiMessage]);
      setIsTyping(false);
    }, 1500);
  };

  const handleQuickQuestion = (question: string) => {
    setInput(question);
  };

  return (
    <div className="min-h-screen bg-[#0a0518]">
      <Navigation />
      
      <div className="pt-24 px-6 pb-6">
        <div className="max-w-7xl mx-auto">
          {/* Header */}
          <div className="mb-6 flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
            <div>
              <h1 className="text-4xl md:text-5xl font-bold mb-2 bg-gradient-to-r from-purple-200 via-pink-200 to-cyan-200 bg-clip-text text-transparent">
                AI Tutor - Stella
              </h1>
              <p className="text-purple-200/70">
                Your personal aerospace learning assistant
              </p>
            </div>
            <div className="flex items-center gap-2">
              <Button
                variant="outline"
                size="sm"
                onClick={() => setLanguage("en")}
                className={`${
                  language === "en"
                    ? "bg-purple-600 text-white border-purple-400"
                    : "border-purple-400/30 text-purple-200 hover:bg-purple-500/10"
                }`}
              >
                <Globe className="w-4 h-4 mr-2" />
                English
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={() => setLanguage("fr")}
                className={`${
                  language === "fr"
                    ? "bg-purple-600 text-white border-purple-400"
                    : "border-purple-400/30 text-purple-200 hover:bg-purple-500/10"
                }`}
              >
                <Globe className="w-4 h-4 mr-2" />
                Français
              </Button>
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
            {/* Chat Area */}
            <div className="lg:col-span-3">
              <div className="bg-gradient-to-br from-purple-900/40 to-blue-900/40 backdrop-blur-xl rounded-2xl border-2 border-purple-400/30 overflow-hidden flex flex-col h-[calc(100vh-280px)]">
                {/* Messages */}
                <div className="flex-1 overflow-y-auto p-6 space-y-4">
                  {messages.map((message) => (
                    <div
                      key={message.id}
                      className={`flex ${message.role === "user" ? "justify-end" : "justify-start"}`}
                    >
                      <div
                        className={`max-w-[80%] rounded-2xl p-4 ${
                          message.role === "user"
                            ? "bg-gradient-to-br from-purple-600 to-pink-600 text-white"
                            : "bg-gradient-to-br from-cyan-900/60 to-blue-900/60 text-cyan-50 border border-cyan-400/20"
                        }`}
                      >
                        {message.role === "assistant" && (
                          <div className="flex items-center gap-2 mb-2">
                            <div className="w-6 h-6 bg-gradient-to-br from-cyan-400 to-blue-500 rounded-full flex items-center justify-center">
                              <Sparkles className="w-3 h-3 text-white" />
                            </div>
                            <span className="text-xs font-semibold text-cyan-200">Stella AI</span>
                          </div>
                        )}
                        <p className="text-sm leading-relaxed">{message.content}</p>
                        <div className="mt-2 text-xs opacity-60">
                          {message.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                        </div>
                      </div>
                    </div>
                  ))}
                  
                  {isTyping && (
                    <div className="flex justify-start">
                      <div className="bg-gradient-to-br from-cyan-900/60 to-blue-900/60 text-cyan-50 border border-cyan-400/20 rounded-2xl p-4 max-w-[80%]">
                        <div className="flex items-center gap-2">
                          <div className="w-2 h-2 bg-cyan-400 rounded-full animate-bounce" />
                          <div className="w-2 h-2 bg-cyan-400 rounded-full animate-bounce" style={{ animationDelay: "0.2s" }} />
                          <div className="w-2 h-2 bg-cyan-400 rounded-full animate-bounce" style={{ animationDelay: "0.4s" }} />
                        </div>
                      </div>
                    </div>
                  )}
                  <div ref={messagesEndRef} />
                </div>

                {/* Quick Questions */}
                {messages.length === 1 && (
                  <div className="px-6 pb-4">
                    <div className="flex items-center gap-2 mb-3">
                      <Lightbulb className="w-4 h-4 text-yellow-400" />
                      <span className="text-sm text-purple-200/70">Quick questions:</span>
                    </div>
                    <div className="flex flex-wrap gap-2">
                      {quickQuestions.map((question, idx) => (
                        <button
                          key={idx}
                          onClick={() => handleQuickQuestion(question)}
                          className="px-3 py-2 bg-purple-500/20 hover:bg-purple-500/30 border border-purple-400/30 rounded-lg text-xs text-purple-100 transition-all hover:scale-105"
                        >
                          {question}
                        </button>
                      ))}
                    </div>
                  </div>
                )}

                {/* Input Area */}
                <div className="p-6 border-t border-purple-400/20 bg-purple-950/20">
                  <div className="flex items-center gap-3">
                    <Button
                      variant="ghost"
                      size="icon"
                      className="text-purple-300 hover:bg-purple-500/20"
                    >
                      <Mic className="w-5 h-5" />
                    </Button>
                    <input
                      type="text"
                      value={input}
                      onChange={(e) => setInput(e.target.value)}
                      onKeyPress={(e) => e.key === "Enter" && handleSend()}
                      placeholder="Ask me anything about aerospace..."
                      className="flex-1 bg-purple-950/40 border border-purple-400/30 rounded-xl px-4 py-3 text-purple-100 placeholder:text-purple-300/50 outline-none focus:border-purple-400/60 transition-colors"
                    />
                    <Button
                      onClick={handleSend}
                      className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white rounded-xl"
                    >
                      <Send className="w-5 h-5" />
                    </Button>
                  </div>
                </div>
              </div>
            </div>

            {/* Sidebar */}
            <div className="space-y-6">
              {/* AI Info */}
              <div className="bg-gradient-to-br from-cyan-900/40 to-blue-900/40 backdrop-blur-xl rounded-2xl border border-cyan-400/30 p-6">
                <div className="flex items-center gap-3 mb-4">
                  <div className="w-12 h-12 bg-gradient-to-br from-cyan-400 to-blue-500 rounded-full flex items-center justify-center animate-glow">
                    <Sparkles className="w-6 h-6 text-white" />
                  </div>
                  <div>
                    <h3 className="text-lg font-semibold text-cyan-100">Stella</h3>
                    <div className="flex items-center gap-2">
                      <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse" />
                      <span className="text-xs text-cyan-200/70">Online</span>
                    </div>
                  </div>
                </div>
                <p className="text-sm text-cyan-100/80">
                  I'm an AI tutor specialized in aerospace education. I can explain concepts in English and French! 🌟
                </p>
              </div>

              {/* Capabilities */}
              <div className="bg-gradient-to-br from-purple-900/40 to-pink-900/40 backdrop-blur-xl rounded-2xl border border-purple-400/30 p-6">
                <h3 className="text-lg font-semibold text-purple-100 mb-4">I Can Help With:</h3>
                <div className="space-y-3">
                  <div className="flex items-start gap-3">
                    <div className="w-8 h-8 bg-purple-500/20 rounded-lg flex items-center justify-center flex-shrink-0">
                      <BookOpen className="w-4 h-4 text-purple-300" />
                    </div>
                    <div>
                      <div className="text-sm font-semibold text-purple-100">Concept Explanation</div>
                      <div className="text-xs text-purple-200/70">Breaking down complex topics</div>
                    </div>
                  </div>
                  <div className="flex items-start gap-3">
                    <div className="w-8 h-8 bg-pink-500/20 rounded-lg flex items-center justify-center flex-shrink-0">
                      <Lightbulb className="w-4 h-4 text-pink-300" />
                    </div>
                    <div>
                      <div className="text-sm font-semibold text-purple-100">Problem Solving</div>
                      <div className="text-xs text-purple-200/70">Step-by-step solutions</div>
                    </div>
                  </div>
                  <div className="flex items-start gap-3">
                    <div className="w-8 h-8 bg-cyan-500/20 rounded-lg flex items-center justify-center flex-shrink-0">
                      <Globe className="w-4 h-4 text-cyan-300" />
                    </div>
                    <div>
                      <div className="text-sm font-semibold text-purple-100">Multilingual</div>
                      <div className="text-xs text-purple-200/70">English & French support</div>
                    </div>
                  </div>
                </div>
              </div>

              {/* Learning Suggestions */}
              <div className="bg-gradient-to-br from-green-900/40 to-emerald-900/40 backdrop-blur-xl rounded-2xl border border-green-400/30 p-6">
                <h3 className="text-lg font-semibold text-green-100 mb-4">Suggested Topics</h3>
                <div className="space-y-2">
                  {suggestions.map((suggestion, idx) => (
                    <button
                      key={idx}
                      onClick={() => handleQuickQuestion(suggestion.topic)}
                      className="w-full flex items-center gap-3 p-3 bg-green-500/10 hover:bg-green-500/20 border border-green-400/20 rounded-xl transition-all group"
                    >
                      <div className="text-2xl">{suggestion.icon}</div>
                      <div className="text-left flex-1">
                        <div className="text-sm font-semibold text-green-100">
                          {suggestion.title}
                        </div>
                      </div>
                      <Sparkles className="w-4 h-4 text-green-300 opacity-0 group-hover:opacity-100 transition-opacity" />
                    </button>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
